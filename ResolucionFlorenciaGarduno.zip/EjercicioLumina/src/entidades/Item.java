package entidades;

public class Item {
	
	private Producto producto;
	private int cantidad;
	
	
	public Item(Producto producto, int cantidad) {
		this.producto = producto;
		this.cantidad = cantidad;
	} 
	
	public double calcularTotal() {
	    double precio= this.producto.getPrecio();
		 double total= precio*this.cantidad;
		 return total;
	}

	public Producto getProducto() {
		return producto;
	}

	public int getCantidad() {
		return cantidad;
	}

	
	
	
}
